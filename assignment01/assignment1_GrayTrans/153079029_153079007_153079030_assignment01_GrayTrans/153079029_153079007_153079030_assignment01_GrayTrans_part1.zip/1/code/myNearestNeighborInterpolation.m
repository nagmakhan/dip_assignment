function myNearestNeighborInterpolation(fname)
% This function will perform Nearest neighbour interpolation on input image, which will be resized to have rows=3M-2,
% columns=2N-1 where (M,N) is size of input image 
%% loading image 
in_img=imread([char(fname) '.png']);
% imshow(in_img);


gray_img=mat2gray(in_img);
[m, n]=size(in_img);

outr_img=zeros(3*m-2,n);
%% row interpolation
% First we perform Nearest neighbour row interpolation to add 2 rows in between 2 rows of
% input image

outr_img(1:3:end,:)=gray_img;
outr_img(2:3:end,:)=gray_img(1:end-1,:);
outr_img(3:3:end,:)=gray_img(2:end,:);
% disp(outr_img);


%%column iterpolation
% Here we perform Nearest neighbour column interpolation on the row interpolated image 
% one column is interpolated between two columns of row interpolated image
out_img=zeros(3*m-2,2*n-1);
out_img(:,1:2:end)=outr_img;
out_img(:,2:2:end)=outr_img(:,1:end-1);
% out_img(:,2:2:end)=cols1;


disp(size(out_img));
% figure
% imshow(out_img);
% disp(fun_img-out_img);
%% Plotting
    myNumOfColors = 200;
    %colour scale
    myColorScale = [ [0:1/(myNumOfColors-1):1]' , ...
[0:1/(myNumOfColors-1):1]' , [0:1/(myNumOfColors-1):1]' ];

    figure
    subplot(1,2,1), imagesc(in_img);
    title('Original Image')
    colormap (myColorScale);
    %aspect ratio
    daspect ([1 1 1]);
    axis equal tight;
    colorbar
    subplot(1,2,2), imagesc(out_img);
    title(['Nearest neighbour interpolation'])
    colormap (myColorScale);
     %aspect ratio
    daspect ([1 1 1]);
    axis equal tight;
    colorbar
    impixelinfo;
    %saving the image
    save(['../images/' char(fname) '_NearestNeighborInterpolation'],'out_img')



end
