%% MyMainScript,
% Please use linux machine to run the code,
%
% when running mymainScript.m working direcory should be codes folder.
%
tic;
% Q1-Image Resizing

%% question 1(a),
%
% To shrink image by factor d,
%
% output is saved as circles_concentric_shrinked2 ,
% circles_concentric_shrinked3
%
myShrinkImageByFactorD(2,'circles_concentric');
myShrinkImageByFactorD(3,'circles_concentric');

%% question 1(b),
% output is saved as barbaraSmall_BilinearInterpolation

myBilinearInterpolation('barbaraSmall'); 

%% question 1(c),
% output is saved as barbaraSmall_NearestNeighborInterpolation

myNearestNeighborInterpolation('barbaraSmall'); 

toc;
